<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{productscategory}prestashop>productscategory_8a4f5a66d0fcc9d13614516db6e3d47a'] = 'Artikel der gleichen Kategorie';
$_MODULE['<{productscategory}prestashop>productscategory_1d269d7f013c3d9d891a146f4379eb02'] = 'Erweitert die Artikelseite um einen Block der Artikel derselben Kategorie anzeigt.';
$_MODULE['<{productscategory}prestashop>productscategory_8dd2f915acf4ec98006d11c9a4b0945b'] = 'Einstellungen erfolgreich aktualisiert';
$_MODULE['<{productscategory}prestashop>productscategory_f4f70727dc34561dfde1a3c529b6205c'] = 'Einstellungen';
$_MODULE['<{productscategory}prestashop>productscategory_e06ba84b50810a88438ae0537405f65a'] = 'Artikelpreis anzeigen';
$_MODULE['<{productscategory}prestashop>productscategory_1d986024f548d57b1d743ec7ea9b09d9'] = 'Preise der eingeblendeten Artikel mitanzeigen';
$_MODULE['<{productscategory}prestashop>productscategory_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Aktiviert';
$_MODULE['<{productscategory}prestashop>productscategory_b9f5c797ebbf55adccdd8539a65a0241'] = 'Deaktiviert';
$_MODULE['<{productscategory}prestashop>productscategory_c9cc8cce247e49bae79f15173ce97354'] = 'Speichern';
$_MODULE['<{productscategory}prestashop>productscategory_1f910bcf84a92cb7c71fa3d926c8a525'] = 'Andere Artikel dieser Kategorie';
$_MODULE['<{productscategory}prestashop>productscategory_dd1f775e443ff3b9a89270713580a51b'] = 'Zurück';
$_MODULE['<{productscategory}prestashop>productscategory_10ac3d04253ef7e1ddc73e6091c0cd55'] = 'Weiter';
$_MODULE['<{productscategory}prestashop>productscategory_4aae87211f77aada2c87907121576cfe'] = 'andere Artikel der gleichen Kategorie:';
$_MODULE['<{productscategory}prestashop>productscategory_2d0f6b8300be19cf35e89e66f0677f95'] = 'In den Warenkorb';


return $_MODULE;
