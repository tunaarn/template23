<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blocksearch}prestashop>blocksearch_e2ca130372651672ba285abd796412ed'] = 'Quick search block';
$_MODULE['<{blocksearch}prestashop>blocksearch_be305c865235f417d9b4d22fcdf9f1c5'] = 'Adds a quick search field to your website.';
$_MODULE['<{blocksearch}prestashop>blocksearch-top_13348442cc6a27032d2b4aa28b75a5d3'] = 'Search';
$_MODULE['<{blocksearch}prestashop>blocksearch_13348442cc6a27032d2b4aa28b75a5d3'] = 'Search';
$_MODULE['<{blocksearch}prestashop>blocksearch_ce1b00a24b52e74de46971b174d2aaa6'] = 'Search products:';
$_MODULE['<{blocksearch}prestashop>blocksearch_5f075ae3e1f9d0382bb8c4632991f96f'] = 'Go';


return $_MODULE;
